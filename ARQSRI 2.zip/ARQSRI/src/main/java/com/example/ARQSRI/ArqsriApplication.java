package com.example.ARQSRI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArqsriApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArqsriApplication.class, args);
	}

}
