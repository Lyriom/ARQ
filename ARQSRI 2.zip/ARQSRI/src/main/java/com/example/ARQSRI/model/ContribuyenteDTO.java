package com.example.ARQSRI.model;

import lombok.Data;

@Data
public class ContribuyenteDTO {
    private String nombreComercial;
    private String tipoContribuyente;
    private String numeroRuc;
    private String nombreLegal;
}
