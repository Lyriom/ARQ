package com.example.ARQSRI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArqsriApplicationTests {

	@Test
	void contextLoads() {
	}

}
